-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2022 at 03:49 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cee_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_acc`
--

CREATE TABLE `admin_acc` (
  `admin_id` int(11) NOT NULL,
  `admin_user` varchar(1000) NOT NULL,
  `admin_pass` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_acc`
--

INSERT INTO `admin_acc` (`admin_id`, `admin_user`, `admin_pass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `course_tbl`
--

CREATE TABLE `course_tbl` (
  `cou_id` int(11) NOT NULL,
  `cou_name` varchar(1000) NOT NULL,
  `cou_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_tbl`
--

INSERT INTO `course_tbl` (`cou_id`, `cou_name`, `cou_created`) VALUES
(67, 'PY_5', '2022-05-09 13:18:46'),
(68, 'PY_4', '2022-05-09 13:18:38'),
(69, 'PY_3', '2022-05-09 13:18:22'),
(70, 'PY_2', '2022-05-09 13:18:10'),
(73, 'PY_1', '2022-05-09 13:17:48');

-- --------------------------------------------------------

--
-- Table structure for table `examinee_tbl`
--

CREATE TABLE `examinee_tbl` (
  `exmne_id` int(11) NOT NULL,
  `exmne_fullname` varchar(1000) NOT NULL,
  `exmne_course` varchar(1000) NOT NULL,
  `exmne_gender` varchar(1000) NOT NULL,
  `exmne_birthdate` varchar(1000) NOT NULL,
  `exmne_year_level` varchar(1000) NOT NULL,
  `exmne_email` varchar(1000) NOT NULL,
  `exmne_password` varchar(1000) NOT NULL,
  `exmne_status` varchar(1000) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `examinee_tbl`
--

INSERT INTO `examinee_tbl` (`exmne_id`, `exmne_fullname`, `exmne_course`, `exmne_gender`, `exmne_birthdate`, `exmne_year_level`, `exmne_email`, `exmne_password`, `exmne_status`) VALUES
(9, 'Ayush', '67', 'male', '2022-05-04', 'fourth year', 'sanghaviayush16@gmail.com', 'Ayush', 'active'),
(10, 'Raj', '67', 'male', '2022-05-12', 'fourth year', 'abc@gmail.com', 'raj123', 'active'),
(11, 'Ravi', '68', 'male', '2022-05-20', 'fourth year', 'xyz@gmail.com', 'Ravi123', 'active'),
(12, 'Vidhi', '69', 'female', '2022-05-18', 'fourth year', 'awa@gmail.com', 'Python', 'active'),
(13, 'Akshay', '69', 'male', '2022-05-12', 'fourth year', 'ak@gmail.com', 'Akashy123', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `exam_answers`
--

CREATE TABLE `exam_answers` (
  `exans_id` int(11) NOT NULL,
  `axmne_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `quest_id` int(11) NOT NULL,
  `exans_answer` varchar(1000) NOT NULL,
  `exans_status` varchar(1000) NOT NULL DEFAULT 'new',
  `exans_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_answers`
--

INSERT INTO `exam_answers` (`exans_id`, `axmne_id`, `exam_id`, `quest_id`, `exans_answer`, `exans_status`, `exans_created`) VALUES
(295, 4, 12, 25, 'Diode, inverted, pointer', 'old', '2019-12-07 02:52:14'),
(296, 4, 12, 16, 'Data Block', 'old', '2019-12-07 02:52:14'),
(297, 6, 12, 18, 'Programmable Logic Controller', 'old', '2019-12-05 12:59:47'),
(298, 6, 12, 9, '1850s', 'old', '2019-12-05 12:59:47'),
(299, 6, 12, 24, '1976', 'old', '2019-12-05 12:59:47'),
(300, 6, 12, 14, 'Operating System', 'old', '2019-12-05 12:59:47'),
(301, 6, 12, 19, 'WAN (Wide Area Network)', 'old', '2019-12-05 12:59:47'),
(302, 6, 11, 28, 'fds', 'new', '2019-12-05 12:04:28'),
(303, 6, 11, 29, 'sd', 'new', '2019-12-05 12:04:28'),
(304, 6, 12, 15, 'David Filo & Jerry Yang', 'new', '2019-12-05 12:59:47'),
(305, 6, 12, 17, 'System file', 'new', '2019-12-05 12:59:47'),
(306, 6, 12, 10, 'Field', 'new', '2019-12-05 12:59:47'),
(307, 6, 12, 9, '1880s', 'new', '2019-12-05 12:59:47'),
(308, 6, 12, 21, 'Temporary file', 'new', '2019-12-05 12:59:47'),
(309, 4, 11, 28, 'q1', 'new', '2019-12-05 13:30:21'),
(310, 4, 11, 29, 'dfg', 'new', '2019-12-05 13:30:21'),
(311, 4, 12, 16, 'Data Block', 'new', '2019-12-07 02:52:14'),
(312, 4, 12, 20, 'Plancks radiation', 'new', '2019-12-07 02:52:14'),
(313, 4, 12, 10, 'Report', 'new', '2019-12-07 02:52:14'),
(314, 4, 12, 24, '1976', 'new', '2019-12-07 02:52:14'),
(315, 4, 12, 9, '1930s', 'new', '2019-12-07 02:52:14'),
(316, 8, 12, 18, 'Programmable Lift Computer', 'new', '2020-01-05 03:18:35'),
(317, 8, 12, 14, 'Operating System', 'new', '2020-01-05 03:18:35'),
(318, 8, 12, 20, 'Einstein oscillation', 'new', '2020-01-05 03:18:35'),
(319, 8, 12, 21, 'Temporary file', 'new', '2020-01-05 03:18:35'),
(320, 8, 12, 25, 'Diode, inverted, pointer', 'new', '2020-01-05 03:18:35'),
(321, 9, 24, 31, 'a)	They are created when you run make migrations command.', 'new', '2022-05-06 11:39:57'),
(322, 9, 24, 40, 'Forgetting passwords on systems since they have too many passwords', 'new', '2022-05-06 11:39:57'),
(323, 9, 24, 36, 'True', 'new', '2022-05-06 11:39:57'),
(324, 9, 24, 35, 'All of these answers', 'new', '2022-05-06 11:39:57'),
(325, 9, 24, 37, 'top1= top2 -1', 'new', '2022-05-06 11:39:57'),
(326, 9, 24, 41, 'Lexemes', 'new', '2022-05-06 11:39:57'),
(327, 9, 24, 38, 'Heap Data Structure like Binary Heap, Fibonacci Heap', 'new', '2022-05-06 11:39:57'),
(328, 9, 24, 32, 'render_to_response', 'new', '2022-05-06 11:39:57'),
(329, 9, 24, 33, 'Templating', 'new', '2022-05-06 11:39:57'),
(330, 9, 24, 39, 'django.utils.global_setting.py', 'new', '2022-05-06 11:39:57'),
(331, 10, 24, 32, 'render', 'new', '2022-05-06 12:42:20'),
(332, 10, 24, 40, 'c)	Not writing passwords down in a safe place, such as a sticky note on your workstation.', 'new', '2022-05-06 12:42:20'),
(333, 10, 24, 38, 'Heap Data Structure like Binary Heap, Fibonacci Heap', 'new', '2022-05-06 12:42:20'),
(334, 10, 24, 41, 'Lexemes', 'new', '2022-05-06 12:42:20'),
(335, 10, 24, 31, 'd)	Migrations are files where Django stores changes to your models.', 'new', '2022-05-06 12:42:20'),
(336, 10, 24, 33, 'Templating', 'new', '2022-05-06 12:42:21'),
(337, 10, 24, 35, 'Fork the Django repository GitHub.', 'new', '2022-05-06 12:42:21'),
(338, 10, 24, 36, 'False', 'new', '2022-05-06 12:42:21'),
(339, 10, 24, 39, 'django.conf.default_setting.py', 'new', '2022-05-06 12:42:21'),
(340, 10, 24, 37, 'top1= top2 -1', 'new', '2022-05-06 12:42:21'),
(341, 11, 26, 45, 'forloop.counter()', 'new', '2022-05-09 12:05:05'),
(342, 11, 26, 42, 'Adrian Holovaty', 'new', '2022-05-09 12:05:05'),
(343, 11, 26, 43, 'MVT', 'new', '2022-05-09 12:05:05'),
(344, 11, 26, 48, 'Schema', 'new', '2022-05-09 12:05:05'),
(345, 11, 26, 46, 'Python Dictionary-Like objects', 'new', '2022-05-09 12:05:05'),
(346, 11, 26, 44, 'The name will be replaced with values of Python variable.', 'new', '2022-05-09 12:05:05'),
(347, 13, 25, 91, 'True', 'new', '2022-05-10 11:03:09'),
(348, 13, 25, 106, 'sqlmigration', 'new', '2022-05-10 11:03:09'),
(349, 13, 25, 102, 'True', 'new', '2022-05-10 11:03:09'),
(350, 13, 25, 109, 'forloop.counter()', 'new', '2022-05-10 11:03:09'),
(351, 13, 25, 107, 'All of the above', 'new', '2022-05-10 11:03:09'),
(352, 13, 25, 113, 'B', 'new', '2022-05-10 11:03:09'),
(353, 13, 25, 110, 'EXTRACT FirstName FROM Persons', 'new', '2022-05-10 11:03:09'),
(354, 13, 25, 101, 'Using domain admin privileged accounts for day-to-day non-admin use.', 'new', '2022-05-10 11:03:09'),
(355, 13, 25, 92, 'It will return the name of the post when Post object is printed.', 'new', '2022-05-10 11:03:09'),
(356, 13, 25, 111, 'picks up second and third record ', 'new', '2022-05-10 11:03:09'),
(357, 13, 25, 94, 'django.conf.global_setting.py', 'new', '2022-05-10 11:03:09'),
(358, 13, 25, 108, 'Asynchronous server', 'new', '2022-05-10 11:03:09'),
(359, 13, 25, 100, 'Backslash character ()', 'new', '2022-05-10 11:03:09'),
(360, 13, 25, 95, 'It will include content from another template having the same templates defined.', 'new', '2022-05-10 11:03:09'),
(361, 13, 25, 90, 'Stack', 'new', '2022-05-10 11:03:09'),
(362, 13, 25, 103, 'Unstored array', 'new', '2022-05-10 11:03:09'),
(363, 13, 25, 88, '{{ name }} will be the output.', 'new', '2022-05-10 11:03:09'),
(364, 13, 25, 89, '1 3 5 1 3 5', 'new', '2022-05-10 11:03:09'),
(365, 13, 25, 96, '10, 9, 4, 5, 7, 6, 8, 2, 1, 3', 'new', '2022-05-10 11:03:09'),
(366, 13, 25, 99, 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id WHERE  SUM (amount) > 200; ', 'new', '2022-05-10 11:03:09'),
(367, 13, 25, 105, 'It is used to caching of the whole website.', 'new', '2022-05-10 11:03:09'),
(368, 13, 25, 97, '0 1 2 3 4 5 6 7 8 9', 'new', '2022-05-10 11:03:09'),
(369, 13, 25, 112, 'django.middleware.cache.AcceleratedCacheMiddleware', 'new', '2022-05-10 11:03:09'),
(370, 13, 25, 93, 'clean(); Field', 'new', '2022-05-10 11:03:09'),
(371, 13, 25, 104, 'manage.py inspectdb', 'new', '2022-05-10 11:03:09');

-- --------------------------------------------------------

--
-- Table structure for table `exam_attempt`
--

CREATE TABLE `exam_attempt` (
  `examat_id` int(11) NOT NULL,
  `exmne_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `examat_status` varchar(1000) NOT NULL DEFAULT 'used'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_attempt`
--

INSERT INTO `exam_attempt` (`examat_id`, `exmne_id`, `exam_id`, `examat_status`) VALUES
(51, 6, 12, 'used'),
(52, 4, 11, 'used'),
(53, 4, 12, 'used'),
(54, 8, 12, 'used'),
(55, 9, 24, 'used'),
(56, 10, 24, 'used'),
(57, 11, 26, 'used'),
(58, 13, 25, 'used');

-- --------------------------------------------------------

--
-- Table structure for table `exam_question_tbl`
--

CREATE TABLE `exam_question_tbl` (
  `eqt_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `exam_question` varchar(1000) NOT NULL,
  `exam_ch1` varchar(1000) NOT NULL,
  `exam_ch2` varchar(1000) NOT NULL,
  `exam_ch3` varchar(1000) NOT NULL,
  `exam_ch4` varchar(1000) NOT NULL,
  `exam_answer` varchar(1000) NOT NULL,
  `exam_status` varchar(1000) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_question_tbl`
--

INSERT INTO `exam_question_tbl` (`eqt_id`, `exam_id`, `exam_question`, `exam_ch1`, `exam_ch2`, `exam_ch3`, `exam_ch4`, `exam_answer`, `exam_status`) VALUES
(9, 12, 'In which decade was the American Institute of Electrical Engineers (AIEE) founded?', '1850s', '1880s', '1930s', '1950s', '1880s', 'active'),
(10, 12, 'What is part of a database that holds only one type of information?', 'Report', 'Field', 'Record', 'File', 'Field', 'active'),
(14, 12, 'OS computer abbreviation usually means ?', 'Order of Significance', 'Open Software', 'Operating System', 'Optical Sensor', 'Operating System', 'active'),
(15, 12, 'Who developed Yahoo?', 'Dennis Ritchie & Ken Thompson', 'David Filo & Jerry Yang', 'Vint Cerf & Robert Kahn', 'Steve Case & Jeff Bezos', 'David Filo & Jerry Yang', 'active'),
(16, 12, 'DB computer abbreviation usually means ?', 'Database', 'Double Byte', 'Data Block', 'Driver Boot', 'Database', 'active'),
(17, 12, '.INI extension refers usually to what kind of file?', 'Image file', 'System file', 'Hypertext related file', 'Image Color Matching Profile file', 'System file', 'active'),
(18, 12, 'What does the term PLC stand for?', 'Programmable Lift Computer', 'Program List Control', 'Programmable Logic Controller', 'Piezo Lamp Connector', 'Programmable Logic Controller', 'active'),
(19, 12, 'What do we call a network whose elements may be separated by some distance? It usually involves two or more small networks and dedicated high-speed telephone lines.', 'URL (Universal Resource Locator)', 'LAN (Local Area Network)', 'WAN (Wide Area Network)', 'World Wide Web', 'WAN (Wide Area Network)', 'active'),
(20, 12, 'After the first photons of light are produced, which process is responsible for amplification of the light?', 'Blackbody radiation', 'Stimulated emission', 'Plancks radiation', 'Einstein oscillation', 'Stimulated emission', 'active'),
(21, 12, '.TMP extension refers usually to what kind of file?', 'Compressed Archive file', 'Image file', 'Temporary file', 'Audio file', 'Temporary file', 'active'),
(22, 12, 'What do we call a collection of two or more computers that are located within a limited distance of each other and that are connected to each other directly or indirectly?', 'Inernet', 'Interanet', 'Local Area Network', 'Wide Area Network', 'Local Area Network', 'active'),
(24, 12, '	 In what year was the \"@\" chosen for its use in e-mail addresses?', '1976', '1972', '1980', '1984', '1972', 'active'),
(25, 12, 'What are three types of lasers?', 'Gas, metal vapor, rock', 'Pointer, diode, CD', 'Diode, inverted, pointer', 'Gas, solid state, diode', 'Gas, solid state, diode', 'active'),
(27, 15, 'asdasd', 'dsf', 'sd', 'yui', 'sdf', 'yui', 'active'),
(28, 11, 'Question 1', 'q1', 'asd', 'fds', 'ytu', 'q1', 'active'),
(29, 11, 'Question 2', 'asd', 'sd', 'q2', 'dfg', 'q2', 'active'),
(30, 11, 'Question 3', 'sd', 'q3', 'asd', 'fgh', 'q3', 'active'),
(31, 24, 'What are Migrations in Django?', 'a)	They are created when you run make migrations command.', 'b)	All of the above', 'c)	They are files saved in migrations directory.', 'd)	Migrations are files where Django stores changes to your models.', 'b)	All of the above', 'active'),
(32, 24, 'Which of the following is the Django shortcut method to more easily render an html response?', 'render', 'render_to_html', 'render_to_response', 'response_render', 'render_to_response', 'active'),
(33, 24, 'What are the features of Django web framework?', 'Form handling', 'All of the above', 'Templating', 'Admin Interface(CRUD)', 'Templating', 'active'),
(35, 24, 'You have found a bug in Django and you want to submit a patch. What will be your correct procedure?', 'Submit a pull request', 'Run Django’s test suits.', 'All of these answers', 'Fork the Django repository GitHub.', 'All of these answers', 'active'),
(36, 24, 'Django was designed to help developers take applications from concept to completion as quickly as possible.', 'False', 'True', '', '', 'True', 'active'),
(37, 24, 'A single array A[1..MAXSIZE] is used to implement two stacks. The two stacks grow from opposite ends of the array. Variables top1 and top2 (topl< top 2) point to the location of the topmost element in each of the stacks. If the space is to be used efficiently, the condition for “stack full” is (GATE CS 2004).', 'top1 + top2 = MAXSIZE', '(top1 = MAXSIZE/2) and (top2 = MAXSIZE/2+1)', '(top1= MAXSIZE/2) or (top2 = MAXSIZE)', 'top1= top2 -1', 'top1= top2 -1', 'active'),
(38, 24, 'A priority queue can efficiently implemented using which of the following data structures? Assume that the number of insert and peek (operation to see the current highest priority item) and extraction (remove the highest priority item) operations are almost same.', 'Heap Data Structure like Binary Heap, Fibonacci Heap', 'None of these', 'Array', 'Linked List', 'Heap Data Structure like Binary Heap, Fibonacci Heap', 'active'),
(39, 24, 'Django supplies sensible default values for settings. In which Python module can you find these settings?', 'django.utils.default_setting.py', 'django.conf.global_setting.py', 'django.utils.global_setting.py', 'django.conf.default_setting.py', 'django.conf.global_setting.py', 'active'),
(40, 24, 'What is one mistake network administrators often make from a security perspective?', 'Enforcing password security on users who do not require it.', 'Forgetting passwords on systems since they have too many passwords', 'c)	Not writing passwords down in a safe place, such as a sticky note on your workstation.', 'Using domain admin privileged accounts for day-to-day non-   admin use.', 'Using domain admin privileged accounts for day-to-day non-   admin use.', 'active'),
(41, 24, 'This is a sorted list of distinct words that have been normalized to merge different variants of the same word, called as?', 'None of the above', 'Tsquery', 'Lexemes', 'UUID', 'Lexemes', 'active'),
(42, 26, 'Django was introduced by _________.', 'Adrian Holovaty', 'Bill Gates', 'Bill Gates', 'Tim Berners-Lee', 'Adrian Holovaty', 'active'),
(43, 26, 'Which architectural pattern does django follow?', 'PHP', 'MVT', 'HTML', 'None of the above', 'MVT', 'active'),
(44, 26, ' What does {{ name }} this mean in Django Templates?', '{{ name }} will be the output.', 'It will be displayed as name in HTML.', 'The name will be replaced with values of Python variable.', 'None of the above', 'The name will be replaced with values of Python variable.', 'active'),
(45, 26, 'Which of the following is a valid forloop attributes of Django Template System?', 'forloop.reverse', 'forloop.firstitem', 'forloop.counter()', 'forloop.lastitem', 'forloop.counter()', 'active'),
(46, 26, 'What are request.GET and request.POST objects?', 'Python Dictionaries', 'Python Lists', 'None of these', 'Python Dictionary-Like objects', 'Python Dictionary-Like objects', 'active'),
(48, 26, 'A Named Collection Of Tables Is Called What In PostgreSQL?', 'Trigger', 'View', 'Diagram', 'Schema', 'Schema', 'active'),
(50, 24, 'How many undirected graphs (not necessarily connected) can be constructed out of a given set V= {V 1, V 2,…V n} of n vertices ?', '2^n', 'n(n)!', '2^(n(n-1)/2)', 'n(n-l)/2', '2^(n(n-1)/2)', 'active'),
(51, 24, 'If arity of operators is fixed, then which of the following notations can be used to parse expressions without parentheses? a) Infix Notation (Inorder traversal of a expression tree) b) Postfix Notation (Postorder traversal of a expression tree) c) Prefix Notation (Preorder traversal of a expression tree)', 'B and C', 'A, B and C', 'None of these', 'Only B', 'B and C', 'active'),
(52, 24, 'Level of a node is distance from root to that node. For example, level of root is 1 and levels of left and right children of root is 2. The maximum number of nodes on level I of a binary tree is?', '2^i', '2^[(i+1)/2]', '2^(i-1)', '2^(i+1)', '2^(i-1)', 'active'),
(53, 24, 'What is the use of per-site caching?', 'It is used to caching of all the pictures on a website.', 'It is used to caching of all the static files.', 'It is used to caching of the whole website.', 'It is used to Caching of all the dynamic files.', 'It is used to caching of the whole website.', 'active'),
(54, 24, 'Consider we have a function, getLCA(), which returns us the Lowest Common Ancestor between 2 nodes of a tree. Using this getLCA() function, how can we calculate the distance between 2 nodes, given that distance from the root, to each node is calculated?', 'dist(u) + dist(v) - dist(getLCA(u, v))', 'dist(u) + dist(v) + 2* dist(getLCA(u, v))', 'dist(u) + dist(v)', 'dist(u) + dist(v) - 2* dist(getLCA(u, v)) ', 'dist(u) + dist(v) - 2* dist(getLCA(u, v)) ', 'active'),
(55, 24, 'Which of these is not a valid backend for caching in django?', 'django.core.cache.backends.sys.memory', 'None of these', 'django.core.cache.backends.db.DatabaseCache', 'django.core.cache.backends.locmem.LocMemCache', 'None of these', 'active'),
(56, 24, '________ command tells PostgreSQL that all of the changes you made to a database should become permanent.', 'Commit', 'Apply', 'Execute ', 'All of the above', 'Commit', 'active'),
(57, 24, 'struct node \r\n{     \r\nint data;     \r\nstruct node* next; \r\n};   \r\nstatic void reverse(struct node** head_ref) \r\n{     \r\n    struct node* prev   = NULL;     \r\n    struct node* current = *head_ref;     \r\n    struct node* next;     \r\n    while (current != NULL)     \r\n   {         \r\n          next  = current->next;           \r\n          current->next = prev;            \r\n          prev = current;         \r\n          current = next;     \r\n    }     \r\n}', '*head_ref = prev;', '*head_ref = current;', '*head_ref = next;', '*head_ref = NULL;', '*head_ref = prev;', 'active'),
(58, 24, 'A meta-command always begins with what?', 'Question mark (?)', 'Forwardslash character (/)', 'Dollar sign ($)', 'Backslash character ()', 'Backslash character ()', 'active'),
(59, 24, 'Which of the following is true regarding Postgres95?', 'Support for SQL was added in 1994', 'Relesed as Prstgres95 In 1995', 'Establishment of the PostgreSQL Global Development Team', 'All of the above', 'All of the above', 'active'),
(60, 24, 'What is the difference between media and static files settings?', 'The media settings hold videos and images while static files hold CSS, JS.', 'The media setting manages files uploaded by the user. Static settings manage the static assets of the website.', 'Both A & B', 'None of the above', 'The media settings hold videos and images while static files hold CSS, JS.', 'active'),
(61, 24, 'Which Of The Following Is True About Modifying Rows In A Table?', 'You can update some rows in a table based on values from another table.', ' If you try to update a record related to an integrity constraint, it raises an error.', 'You can modify multiple columns.', 'All of the above.', 'All of the above.', 'active'),
(62, 24, 'We Add Data To PostgreSQL By Using Which Statement?', 'ADD', 'INSERT', 'UPDATE', 'SELECT', 'INSERT', 'active'),
(66, 24, 'Let A be a square matrix of size n x n. Consider the following program. What is the expected output?  C = 100 for i = 1 to n do     for j = 1 to n do     {         Temp = A[i][j] + C         A[i][j] = A[j][i]         A[j][i] = Temp - C     }  for i = 1 to n do     for j = 1 to n do         Output(A[i][j]);   ', 'The matrix A itself', 'Adding 100 to the upper diagonal and substracting 100 from diagonal elements of A', 'Tranpose of matrix A', 'None of the above', 'The matrix A itself', 'active'),
(67, 24, '_______ is the smallest unit inside the given program.', 'Keyword', 'Identifier ', 'Lietral', 'Token', 'Token', 'active'),
(68, 26, 'Which of the following statement is true regarding PostgreSQL?', 'PostgreSQL is a powerful database system', 'PostgreSQL is open source database system', 'PostgreSQL is object-relation database system', 'All of the above', 'All of the above', 'active'),
(69, 26, 'Which of the following is true regarding Postgres95?', 'Support for SQL was added in 1994', 'Released as Postgres95 in 1995', 'All of the above', 'Establishment of the PostgreSQL Global Development Team', 'All of the above', 'active'),
(70, 26, 'Which of these is not a valid backend for caching in django?', 'django.core.cache.backends.sys.memory', 'django.core.cache.backends.db.DatabaseCache', 'None of the these', 'django.core.cache.backends.locmem.LocMemCache', 'django.core.cache.backends.sys.memory', 'active'),
(71, 26, 'What are Migrations in Django?', 'They are files saved in migrations directory.', 'They are created when you run make migrations command.', 'Migrations are files where Django stores changes to your models.', 'All of the above', 'All of the above', 'active'),
(72, 26, 'The below command is used to?  ANALYZE [ VERBOSE ] [ table [ (column [, ...] ) ] ]', 'Collect statistics about a database. ', 'Start a transaction block.', 'End a transaction block.', 'Destroy statistics about a database.', 'Collect statistics about a database. ', 'active'),
(73, 26, 'What is one mistake network administrators often make from a security perspective?', 'Forgetting passwords on systems since they have too many passwords.', 'Using domain admin privileged accounts for day-to-day non-admin use.', 'Not writing passwords down in a safe place, such as a sticky note on your workstation.', 'Enforcing password security on users who do not require it.', 'Using domain admin privileged accounts for day-to-day non-admin use.', 'active'),
(74, 26, '_______ is the smallest unit inside the given program.', 'Keyword', 'Identifier ', 'Lietral', 'Token', 'Token', 'active'),
(75, 26, 'Which of the following data structure works on insertion at only one end but deletions at both ends of the list?', 'Priority Queues', 'Input - restricted deque', 'Output - restricted deque', 'Stack', 'Input - restricted deque', 'active'),
(76, 26, 'How does breadth-first work?', 'Traverse each incident node along with its children', 'Traverse all node in random order', 'Is the same as backtracking', 'Traverse all neighbor nodes before moving to their child', 'Traverse all neighbor nodes before moving to their child', 'active'),
(77, 26, 'Which command is used to select the customer who has been spending more than 200?', 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id WHERE  amount > 200;', 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id WHERE  SUM (amount) > 200; ', 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id WHERE  SUM (amount) > 200; ', 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id  HAVING amount > 200;', 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id WHERE  SUM (amount) > 200; ', 'active'),
(78, 26, 'Suppose the numbers 7, 5, 1, 8, 3, 6, 0, 9, 4, 2 are inserted in that order into an initially empty binary search tree. The binary search tree uses the usual ordering on natural numbers. What is the in-order traversal sequence of the resultant tree?', '0 1 2 3 4 5 6 7 8 9', '9 8 6 4 3 2 0 1 5 7', '7 5 1 0 3 2 4 6 8 9', '0 2 4 3 1 6 5 9 8 7', '0 1 2 3 4 5 6 7 8 9', 'active'),
(79, 26, 'Consider a hash table of size seven, with starting index zero, and a hash function (3x + 4)mod7. Assuming the hash table is initially empty, which of the following is the contents of the table when the sequence 1, 3, 8, 10 is inserted into the table using closed hashing? Note that ‘_’ denotes an empty location in the table.', '8, _, _, _, _, _, 10', '1, 8, 10, _, _, _, 3', '1, _, _, _, _, _,3', '1, 10, 8, _, _, _, 3', '1, 8, 10, _, _, _, 3', 'active'),
(80, 26, 'Following is C like pseudo code of a function that takes a number as an argument, and uses a stack S to do processing. void fun(int n) {     Stack S;      while (n > 0)     {       push(&S, n%2);       n = n/2;     }     while (!isEmpty(&S))       printf(\"%d \", pop(&S));  }   ', 'Prints binary representation of n in reverse order', 'Prints binary representation of n', 'Prints the value of Logn in reverse order', 'Prints the value of Logn', 'Prints the value of Logn', 'active'),
(81, 26, 'What does the following statement do? CREATE INDEX lower_title_idx ON books ((lower(title)));', 'Modifies an index in place to be lowercase ', 'Creates a new index with a special operator class ‘lower’ for case insensitive comparisons ', 'Creates an index for efficient case-insensitive searches on the titles column within the books table ', 'Nothing, it’s invalid SQL', 'Creates an index for efficient case-insensitive searches on the titles column within the books table ', 'active'),
(82, 26, 'In a complete k-ary tree, every internal node has exactly k children or no child. The number of leaves in such a tree with n internal nodes is?', 'nk', 'n(k-1) + 1', 'n(k-1)', '(n-1)k + 1', 'n(k-1) + 1', 'active'),
(83, 26, 'Which of the following is the Django shortcut method to more easily render an html response?', 'Render', 'render_to_html', 'render_to_response', 'response_render', 'render_to_response', 'active'),
(85, 26, 'Django was designed to help developers take applications from concept to completion as quickly as possible.', 'True', 'None', 'False', 'Both True & False', 'True', 'active'),
(86, 26, 'A 3-ary max heap is like a binary max heap, but instead of 2 children, nodes have 3 children. A 3-ary heap can be represented by an array as follows: The root is stored in the first location, a[0], nodes in the next level, from left to right, is stored from a[1] to a[3]. The nodes from the second level of the tree from left to right are stored from a[4] location onward. An item x can be inserted into a 3-ary heap containing n items by placing x in the location a[n] and pushing it up the tree to satisfy the heap property.  Which one of the following is a valid sequence of elements in an array representing 3-ary max heap?', '1, 3, 5, 6, 8, 9', '9, 6, 3, 1, 8, 5', '9, 3, 6, 8, 5, 1', '9, 5, 6, 8, 3, 1', '9, 5, 6, 8, 3, 1', 'active'),
(87, 26, 'Which of the following is true about a group function?', 'Group functions operate on set of rows to produce multiple results per group', 'Group functions ignore NULL values ', 'DISTINCT keyword makes a group function consider duplicate values ', 'None of the above', 'Group functions ignore NULL values ', 'active'),
(88, 25, 'What does {{ name }} this mean in Django Templates?', '{{ name }} will be the output.', 'It will be displayed as name in HTML.', 'The name will be replaced with values of Python variable.', 'None of the above', 'The name will be replaced with values of Python variable.', 'active'),
(89, 25, 'What is the output of following function for start pointing to first node of following linked list? 1->2->3->4->5->6  void fun(struct node* start) {   if(start == NULL)     return;   printf(\"%d  \", start->data);       if(start->next != NULL )     fun(start->next->next);   printf(\"%d  \", start->data); }  ', '1 4 6 6 4 1', '1 3 5 1 3 5', '1 2 3 5', '1 3 5 5 3 1', '1 3 5 5 3 1', 'active'),
(90, 25, 'If we want to convert infix notation to postfix notation, then which of the following data structure should we use?', 'Stack', 'Queue', 'Singly Linked List', 'HashMap', 'Stack', 'active'),
(91, 25, 'Django was designed to help developers take applications from concept to completion as slow as possible.', 'True', 'None', 'False', 'Both True $ False', 'False', 'active'),
(92, 25, 'What is the purpose of __str__() method?   class Post(models.Model):     post_heading = models.CharField(max_length=200)     post_text = models.TextField()     post_author = models.CharField(max_length=100, default=’anonymous’)     def__str__(self):         return self.post_heading', 'It displays a human-readable form of object.', 'It will display the post_heading when __str__() is called.', 'It will return the name of the post when Post object is printed.', 'None of the above', 'It will return the name of the post when Post object is printed.', 'active'),
(93, 25, 'To automatically provide a value for a field, or to do validation that requires access to more than a single field, you should override the ___ method in the ___ class.', 'validate(); Model', 'group(); Model', 'validate(); Form', 'clean(); Field', 'clean(); Field', 'active'),
(94, 25, 'Django supplies sensible default values for settings. In which Python module can you find these settings?', 'django.utils.default_setting.py', 'django.utils.global_setting.py', 'django.conf.default_setting.py', 'django.conf.global_setting.py', 'django.conf.global_setting.py', 'active'),
(95, 25, 'What does {% include %} does?', 'It will include another template.', 'It will include content from another template having the same templates defined.', 'It is the same as {% extend %}.', 'None of the above', 'It will include another template.', 'active'),
(96, 25, 'Suppose the elements 7, 2, 10 and 4 are inserted, in that order, into the valid 3- ary max heap found in the above question, Which one of the following is the sequence of items in the array representing the resultant heap?', '10, 7, 9, 8, 3, 1, 5, 2, 6, 4', '10, 9, 8, 7, 6, 5, 4, 3, 2, 1', '10, 9, 4, 5, 7, 6, 8, 2, 1, 3', '10, 8, 6, 9, 7, 2, 3, 4, 1, 5', '10, 7, 9, 8, 3, 1, 5, 2, 6, 4', 'active'),
(97, 25, 'Suppose the numbers 7, 5, 1, 8, 3, 6, 0, 9, 4, 2 are inserted in that order into an initially empty binary search tree. The binary search tree uses the usual ordering on natural numbers. What is the in-order traversal sequence of the resultant tree?', '7 5 1 0 3 2 4 6 8 9', '0 2 4 3 1 6 5 9 8 7', '0 1 2 3 4 5 6 7 8 9', '9 8 6 4 3 2 0 1 5 7', '0 1 2 3 4 5 6 7 8 9', 'active'),
(99, 25, 'which command is used to select the customer who has been spending more than 200?', 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id WHERE  amount > 200;', 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id WHERE  SUM (amount) < 200; ', 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id WHERE  SUM (amount) > 200; ', 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id  HAVING amount > 200;', 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id WHERE  SUM (amount) > 200; ', 'active'),
(100, 25, 'A meta-command always begins with what?', 'Forwardslash character (/)', 'Dollar sign ($)', 'Backslash character ()', 'Question mark (?)', 'Backslash character ()', 'active'),
(101, 25, 'What is one mistake network administrators often make from a security perspective?', 'Forgetting passwords on systems since they have too many passwords.', 'Enforcing password security on users who do not require it.', 'Not writing passwords down in a safe place, such as a sticky note on your workstation.', 'Using domain admin privileged accounts for day-to-day non-admin use.', 'Using domain admin privileged accounts for day-to-day non-admin use.', 'active'),
(102, 25, 'Django was designed to help developers take applications from concept to completion as quickly as possible.', 'True', 'None', 'False', 'None of the above', 'True', 'active'),
(103, 25, 'An algorithm performs (logN)1/2 find operations, N insert operations, (logN)1/2 delete operations, and (logN)1/2 decrease-key operations on a set of data items with keys drawn from a linearly ordered set. For a delete operation, a pointer is provided to the record that must be deleted. For the decrease-key operation, a pointer is provided to the record that has its key decreased. Which one of the following data structures is the most suited for the algorithm to use, if the goal is to achieve the best total asymptotic complexity considering all the operations?', 'Unstored array', 'Min-heap', 'Sorted array', 'Sorted doubly linked list', 'Unstored array', 'active'),
(104, 25, 'What is the Django command to view a database schema of an existing (or legacy) database?', 'manage.py inspect', 'manage.py legacydb', 'manage.py inspectdb', 'None of the above', 'manage.py inspectdb', 'active'),
(105, 25, 'What is the use of per-site caching?', 'It is used to caching of all the pictures on a website.', 'It is used to caching of the whole website.', 'It is used to Caching of all the dynamic files.', 'It is used to caching of all the static files.', 'It is used to caching of the whole website.', 'active'),
(106, 25, 'Which of these commands are used to print the SQL query of the model?', 'migrate', 'makemigration', 'sqlmigration', 'showmigration', 'sqlmigration', 'active'),
(107, 25, 'Which of the following statement is true regarding PostgreSQL?', 'PostgreSQL is a powerful database system', 'PostgreSQL is open source database system', 'PostgreSQL is object-relation database system', 'All of the above', 'All of the above', 'active'),
(108, 25, 'What does the file asgi.py refer to?', 'Asynchronous server', 'Application server', 'App server', 'App services', 'Asynchronous server', 'active'),
(109, 25, 'Which of the following is a valid forloop attributes of Django Template System?', 'forloop.reverse', 'forloop.firstitem', 'forloop.counter()', 'forloop.lastitem', 'forloop.counter()', 'active'),
(110, 25, 'With SQL, how do you select a column named \"FirstName\" from a table named \"Persons\"?', 'SELECT Persons.FirstName', 'EXTRACT FirstName FROM Persons', 'None of these', 'SELECT FirstName FROM Persons', 'SELECT FirstName FROM Persons', 'active'),
(111, 25, 'What does the following query do?  SELECT * FROM CUSTOMER LIMIT 3 OFFSET 2;', 'picks up three records ', 'picks up three records starting from the second position ', 'picks up second and third record ', 'throws an error', 'picks up three records starting from the second position ', 'active'),
(112, 25, 'To cache your entire site for an application in Django, you add all except which of these settings?', 'django.middleware.common.CommonMiddleware', 'django.middleware.cache.UpdateCacheMiddleware', 'django.middleware.cache.FetchFromCacheMiddleware', 'django.middleware.cache.AcceleratedCacheMiddleware', 'django.middleware.cache.AcceleratedCacheMiddleware', 'active'),
(113, 25, 'We have a binary heap on n elements and wish to insert n more elements (not necessarily one after another) into this heap. The total time required for this is (A) Theta(logn) (B) 	Theta(n) (C) 	Theta(nlogn) (D) 	Theta(n^2)', 'A', 'B', 'C', 'D', 'B', 'active'),
(114, 27, ') The following C function takes a single-linked list of integers as a parameter and rearranges the elements of the list. The function is called with the list containing the integers 1, 2, 3, 4, 5, 6, 7 in the given order. What will be the contents of the list after the function completes execution?  struct node  {   int value;   struct node *next; }; void rearrange(struct node *list) {   struct node *p, * q;   int temp;   if ((!list) || !list->next)        return;   p = list;   q = list->next;   while(q)    {      temp = p->value;      p->value = q->value;      q->value = temp;      p = q->next;      q = p?p->next:0;   } }  ', '1,2,3,4,5,6,7', '2,1,4,3,6,5,7', '1,3,2,5,4,7,6', '2,3,4,5,6,7,1', '2,3,4,5,6,7,1', 'active'),
(116, 27, 'Match the pairs in the following questions:   List 1 A) repeat until, B) Pointer date type, C) Coercion, D) Activation method .......    List 2 1) Dynamic Data Structiure, 2) Recursion, 3) Nondeterministic loop 4) Type Conversion', 'A – 2, B – 1, C – 4, D – 3', 'A – 3, B – 4, C – 1, D – 2', 'A – 3, B – 4, C – 1, D – 2', 'A – 3, B – 1, C – 4, D – 2', 'A – 3, B – 1, C – 4, D – 2', 'active'),
(117, 27, 'PostgreSQL used what model of communication?', 'Network', 'Cline/Server', 'Peer-to-Peer', 'Push Model', 'Cline/Server', 'active'),
(118, 27, 'If we want to convert infix notation to postfix notation, then which of the following data structure should we use?', 'Stack', 'Queue', 'Singly Linked List', 'HashMap', 'Stack', 'active'),
(119, 27, 'What does {% include %} does?', 'It will include another template.', 'It will include content from another template having the same templates defined.', 'It is the same as {% extend %}.', 'None of the above', 'It will include another template.', 'active'),
(120, 27, 'Which command is used to select the customer who has been spending more than 200?', 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id WHERE  amount > 200;', ' SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id WHERE  SUM (amount) < 200; ', 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id WHERE  SUM (amount) > 200; ', 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id HAVING amount > 200;', 'SELECT customer_id, SUM (amount) FROM payment GROUP BY customer_id WHERE  SUM (amount) > 200; ', 'active'),
(121, 27, 'Numeric types consist of?', 'two-byte', 'seven-byte', 'zero-byte', 'All of the above', 'two-byte', 'active'),
(122, 27, 'Using psql, you can generate a complete list of commands by using the ________ command', 'help', '/help', '$help', '&help', 'help', 'active'),
(123, 27, 'Which syntax is used to Change the definition of a procedural language?', 'UPDATE LANGUAGE name RENAME TO new_name', 'ALTER LANGUAGE name RENAME TO new_name', 'ALTER LANGUAGE name OWNER TO new_name', 'UPDATE LANGUAGE name OWNER TO new_name', 'ALTER LANGUAGE name RENAME TO new_name', 'active'),
(124, 27, 'This is admin.py file in an application. It will register models Post and Like in Django Admin site. from django.contrib import admin from .models import Post, Like, Subscribe # DataFlair admin.site.register(Post) admin.site.register(Like) admin.site.register(Subscribe)', 'False', 'True', 'None', 'Both', 'True', 'active'),
(125, 27, 'What is the use of per-site caching?', 'It is used to caching of all the pictures on a website.', 'It is used to caching of the whole website.', 'It is used to Caching of all the dynamic files.', 'It is used to caching of all the static files.', 'It is used to caching of the whole website.', 'active'),
(126, 27, 'In the worst case, the number of comparisons needed to search a singly linked list of length n for a given element is (GATE CS 2002)', 'log 2 n', 'n/2', 'log 2n - 1', 'n', 'n', 'active'),
(127, 27, 'What does admin.autodiscover() do?', 'It will look through INSTALLED_APPS when admin is requested.', ' If the installed apps have admin.py it will execute them.', 'None of these', 'Both a and b', 'Both a and b', 'active'),
(128, 27, 'What is the Django command to view a database schema of an existing (or legacy) database?', 'manage.py inspect', 'manage.py inspectdb', 'manage.py legacydb', 'None of the above', 'manage.py inspectdb', 'active'),
(129, 27, 'Which of the following is the time complexity of converting a prefix notation to infix notation is?', 'O(n) where n is the length of the equation', 'O(n) where n is number of operands', 'O(1)', 'O(logn) where n is length of the equation', 'O(n) where n is the length of the equation', 'active'),
(130, 27, 'Which of these commands are used to print the SQL query of the model?', 'migrate', 'makemigrations', 'sqlmigrations', 'showmigration', 'sqlmigrations', 'active'),
(131, 27, 'What is request.META in request object?', 'It is a python directory.', 'It containsall the HTTP Headers associated with a particular request.', 'It contains the user’s IP address and machine specification. ', 'All of the above', 'All of the above', 'active'),
(132, 27, 'Which of the following statement is true in linked list implementation of queue?', 'In push operation, if new nodes are inserted at the beginning, then in pop operation, nodes must be removed from the beginning', 'In push operation, if new nodes are inserted at the end, then in pop operation, nodes must be removed from the end', 'In a push operation, if new nodes are inserted at the end, then in pop operation, nodes must be removed from beginning.', 'In push operation, if new nodes are inserted at the beginning of linked list, then in pop operation, nodes must be removed from end', 'In push operation, if new nodes are inserted at the beginning of linked list, then in pop operation, nodes must be removed from end', 'active'),
(133, 27, 'What will happen on execution of this command : > python manage.py createsuperuser', 'It will create an admin superuser', 'It will ask for name and password of the superuser.', ' Both a and b', 'None of the above', ' Both a and b', 'active'),
(134, 27, 'In Post.models.file () you can pass multiple parameters in filter() to narrow your result/s.', 'True', 'False', '', '', 'False', 'active'),
(135, 27, 'What does the following query do?  SELECT * FROM CUSTOMER LIMIT 3 OFFSET 2;', 'picks up three records ', 'picks up three records starting from the second position ', 'picks up second and third record ', 'throws an error', 'picks up three records starting from the second position ', 'active'),
(136, 27, 'What does the file asgi.py refer to?', 'Asynchronous server', 'App services ', 'Application server', 'App server', 'Asynchronous server', 'active'),
(137, 27, 'In a min-heap with n elements with the smallest element at the root, the 7th smallest element can be found in time a) 	heta(n log n) b) 	heta(n) c) 	heta(log n) d) 	heta(1)  The question was not clear in original GATE exam. For clarity, assume that there are no duplicates in Min-Heap and accessing heap elements below root is allowed.', 'a', 'b', 'c', 'd', 'd', 'active'),
(138, 27, 'Which best practice is NOT relevant to migrations?', 'To make sure that your migrations are up to date, you should run updatemigrations before running your tests.', ' You should back up your production database before running a migration.', 'Your migration code should be under source control.', ' If a project has a lot of data, you should test against a staging copy before running the migration on production.', 'To make sure that your migrations are up to date, you should run updatemigrations before running your tests.', 'active'),
(139, 27, 'Which variable name is best according to PEP 8 guidelines?', 'numFingers  ', 'number-of-Fingers', ' number_of_fingers ', ' finger_num', ' number_of_fingers ', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `exam_tbl`
--

CREATE TABLE `exam_tbl` (
  `ex_id` int(11) NOT NULL,
  `cou_id` int(11) NOT NULL,
  `ex_title` varchar(1000) NOT NULL,
  `ex_time_limit` varchar(1000) NOT NULL,
  `ex_questlimit_display` int(11) NOT NULL,
  `ex_description` varchar(1000) NOT NULL,
  `ex_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_tbl`
--

INSERT INTO `exam_tbl` (`ex_id`, `cou_id`, `ex_title`, `ex_time_limit`, `ex_questlimit_display`, `ex_description`, `ex_created`) VALUES
(24, 73, 'TEST CODE (CBJGNB)', '30', 25, 'Python, Django, Data Structure, PostgreSQL', '2022-05-10 11:13:41'),
(25, 69, 'TEST CODE  (HHWSNO)', '30', 25, 'Python, Django, Data Structure, PostgreSQL', '2022-05-10 11:13:27'),
(26, 70, 'TEST CODE (ZGAJIV)', '30', 25, 'Python, Django, Data Structure, PostgreSQL', '2022-05-10 11:13:18'),
(27, 68, 'TEST CODE  (SMHGFP)', '30', 25, 'Python, Django, Data Structure, PostgreSQL', '2022-05-10 11:13:08'),
(28, 67, 'TEST CODE (jx2MWO)', '30', 25, 'Python, Django, Data Structure, PostgreSQL', '2022-05-10 11:12:53');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks_tbl`
--

CREATE TABLE `feedbacks_tbl` (
  `fb_id` int(11) NOT NULL,
  `exmne_id` int(11) NOT NULL,
  `fb_exmne_as` varchar(1000) NOT NULL,
  `fb_feedbacks` varchar(1000) NOT NULL,
  `fb_date` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedbacks_tbl`
--

INSERT INTO `feedbacks_tbl` (`fb_id`, `exmne_id`, `fb_exmne_as`, `fb_feedbacks`, `fb_date`) VALUES
(4, 6, 'Glenn Duerme', 'Gwapa kay Miss Pam', 'December 05, 2019'),
(5, 6, 'Anonymous', 'Amazing!!!', 'December 05, 2019'),
(6, 4, 'Rogz Nunezsss', 'Yes', 'December 08, 2019'),
(7, 4, '', '', 'December 08, 2019'),
(8, 4, '', '', 'December 08, 2019'),
(9, 8, 'Anonymous', 'dfsdf', 'January 05, 2020'),
(10, 9, 'Anonymous', 'Good!!', 'May 09, 2022');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_acc`
--
ALTER TABLE `admin_acc`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `course_tbl`
--
ALTER TABLE `course_tbl`
  ADD PRIMARY KEY (`cou_id`);

--
-- Indexes for table `examinee_tbl`
--
ALTER TABLE `examinee_tbl`
  ADD PRIMARY KEY (`exmne_id`);

--
-- Indexes for table `exam_answers`
--
ALTER TABLE `exam_answers`
  ADD PRIMARY KEY (`exans_id`);

--
-- Indexes for table `exam_attempt`
--
ALTER TABLE `exam_attempt`
  ADD PRIMARY KEY (`examat_id`);

--
-- Indexes for table `exam_question_tbl`
--
ALTER TABLE `exam_question_tbl`
  ADD PRIMARY KEY (`eqt_id`);

--
-- Indexes for table `exam_tbl`
--
ALTER TABLE `exam_tbl`
  ADD PRIMARY KEY (`ex_id`);

--
-- Indexes for table `feedbacks_tbl`
--
ALTER TABLE `feedbacks_tbl`
  ADD PRIMARY KEY (`fb_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_acc`
--
ALTER TABLE `admin_acc`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `course_tbl`
--
ALTER TABLE `course_tbl`
  MODIFY `cou_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `examinee_tbl`
--
ALTER TABLE `examinee_tbl`
  MODIFY `exmne_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `exam_answers`
--
ALTER TABLE `exam_answers`
  MODIFY `exans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=372;

--
-- AUTO_INCREMENT for table `exam_attempt`
--
ALTER TABLE `exam_attempt`
  MODIFY `examat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `exam_question_tbl`
--
ALTER TABLE `exam_question_tbl`
  MODIFY `eqt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `exam_tbl`
--
ALTER TABLE `exam_tbl`
  MODIFY `ex_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `feedbacks_tbl`
--
ALTER TABLE `feedbacks_tbl`
  MODIFY `fb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
